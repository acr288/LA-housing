# LA-housing
LA housing price change 1999-2018
